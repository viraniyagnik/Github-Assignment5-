﻿using System;
using System.Collections;

namespace A5.Task1
{
	/*
	public class LinkedSet2 : DoublyLinkedList, ISet
	{
	}
	*/
}
